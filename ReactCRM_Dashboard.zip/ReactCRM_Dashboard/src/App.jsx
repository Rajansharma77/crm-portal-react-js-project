import { useMemo, useState } from 'react';
import {
  LayoutDashboard, Users, ContactRound, ChartNoAxesCombined, Settings,
  Search, Bell, Plus, ChevronDown, MoreHorizontal, ArrowUpRight,
  ArrowDownRight, Menu, X, Download, Filter, CalendarDays, CircleDollarSign,
  Target, Clock3, CheckCircle2, Mail, Phone, Command
} from 'lucide-react';

const initialLeads = [
  { id: 1, name: 'Aarav Mehta', company: 'BrightPath Solutions', email: 'aarav@brightpath.io', phone: '+91 98765 43210', value: 48000, status: 'Qualified', source: 'Website', owner: 'Priya S.', initials: 'AM', color: 'violet', date: 'Nov 05, 2026' },
  { id: 2, name: 'Ananya Sharma', company: 'Northstar Retail', email: 'ananya@northstar.in', phone: '+91 98111 22334', value: 32500, status: 'Proposal', source: 'Referral', owner: 'Rahul K.', initials: 'AS', color: 'peach', date: 'Nov 04, 2026' },
  { id: 3, name: 'Kabir Khan', company: 'CloudNine Tech', email: 'kabir@cloudnine.com', phone: '+91 99887 76655', value: 72000, status: 'New', source: 'LinkedIn', owner: 'Priya S.', initials: 'KK', color: 'blue', date: 'Nov 03, 2026' },
  { id: 4, name: 'Diya Patel', company: 'GreenLeaf Foods', email: 'diya@greenleaf.co', phone: '+91 98989 12345', value: 18500, status: 'Won', source: 'Website', owner: 'Arjun M.', initials: 'DP', color: 'green', date: 'Nov 02, 2026' },
  { id: 5, name: 'Ishaan Verma', company: 'Vertex Digital', email: 'ishaan@vertex.dev', phone: '+91 97777 11223', value: 56000, status: 'Lost', source: 'Campaign', owner: 'Rahul K.', initials: 'IV', color: 'pink', date: 'Nov 01, 2026' },
  { id: 6, name: 'Meera Iyer', company: 'UrbanNest Homes', email: 'meera@urbannest.in', phone: '+91 96666 55443', value: 41500, status: 'Qualified', source: 'Referral', owner: 'Arjun M.', initials: 'MI', color: 'yellow', date: 'Oct 30, 2026' },
];

const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const statusClass = (status) => status.toLowerCase();

function App() {
  const [leads, setLeads] = useState(initialLeads);
  const [activeNav, setActiveNav] = useState('Overview');
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All statuses');
  const [showModal, setShowModal] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ name: '', company: '', email: '', phone: '', value: '', source: 'Website', owner: 'Priya S.' });

  const filtered = useMemo(() => leads.filter((lead) => {
    const matchesQuery = `${lead.name} ${lead.company} ${lead.email}`.toLowerCase().includes(query.toLowerCase());
    const matchesStatus = statusFilter === 'All statuses' || lead.status === statusFilter;
    return matchesQuery && matchesStatus;
  }), [leads, query, statusFilter]);

  const totalPipeline = leads.filter(l => !['Won', 'Lost'].includes(l.status)).reduce((sum, l) => sum + l.value, 0);
  const wonCount = leads.filter(l => l.status === 'Won').length;
  const conversion = leads.length ? Math.round((wonCount / leads.length) * 100) : 0;

  function addLead(e) {
    e.preventDefault();
    const name = form.name.trim();
    if (!name || !form.company.trim() || !form.email.trim() || !form.value) return;
    const newLead = {
      ...form, id: Date.now(), name, value: Number(form.value), status: 'New',
      initials: name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase(),
      color: 'blue', date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    };
    setLeads(prev => [newLead, ...prev]);
    setForm({ name: '', company: '', email: '', phone: '', value: '', source: 'Website', owner: 'Priya S.' });
    setShowModal(false);
    setNotice('Lead added successfully');
    setTimeout(() => setNotice(''), 2600);
  }

  function changeStatus(id, status) {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
  }

  function exportCsv() {
    const rows = [['Name','Company','Email','Phone','Value','Status','Source','Owner'], ...filtered.map(l => [l.name,l.company,l.email,l.phone,l.value,l.status,l.source,l.owner])];
    const csv = rows.map(row => row.map(v => `"${String(v ?? '').replaceAll('"','""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a'); a.href = url; a.download = 'novacrm-leads.csv'; a.click(); URL.revokeObjectURL(url);
  }

  const navItems = [
    { label: 'Overview', icon: LayoutDashboard },
    { label: 'Leads', icon: ContactRound, count: leads.length },
    { label: 'Contacts', icon: Users },
    { label: 'Reports', icon: ChartNoAxesCombined },
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        <div className="brand"><div className="brand-mark"><Command size={19}/></div><span>nova<span className="brand-light">crm</span></span><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={18}/></button></div>
        <div className="workspace-label">WORKSPACE</div>
        <div className="workspace"><div className="workspace-avatar">A</div><div><strong>Acme Studio</strong><small>Free workspace</small></div><ChevronDown size={15}/></div>
        <div className="nav-label">MENU</div>
        <nav>{navItems.map(({label, icon: Icon, count}) => <button key={label} className={`nav-item ${activeNav === label ? 'active' : ''}`} onClick={() => {setActiveNav(label);setMobileOpen(false);}}><Icon size={18}/><span>{label}</span>{count !== undefined && <small className="nav-count">{count}</small>}</button>)}</nav>
        <div className="nav-label tools-label">PREFERENCES</div>
        <button className="nav-item" onClick={() => setNotice('Settings panel is a demo placeholder')}><Settings size={18}/><span>Settings</span></button>
        <div className="sidebar-bottom"><div className="help-card"><div className="help-icon">✦</div><strong>Need a hand?</strong><p>Visit our help center to get the most out of NovaCRM.</p><button onClick={() => setNotice('Help center is a demo placeholder')}>Visit help center <ArrowUpRight size={13}/></button></div><div className="profile"><div className="profile-avatar">RS</div><div><strong>Rajan Sharma</strong><small>Admin</small></div><MoreHorizontal size={18}/></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><div className="topbar-left"><button className="mobile-menu" onClick={() => setMobileOpen(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{activeNav}</b></div></div><div className="topbar-actions"><div className="top-search"><Search size={16}/><input placeholder="Search anything..." value={query} onChange={e => setQuery(e.target.value)}/><kbd>⌘ K</kbd></div><button className="icon-button notification" onClick={() => setNotice('You are all caught up!')}><Bell size={18}/><i/></button><div className="top-avatar">RS</div></div></header>

        <div className="page-wrap">
          <section className="page-heading"><div><div className="eyebrow"><span className="live-dot"/> MONDAY, NOVEMBER 06, 2026</div><h1>{activeNav === 'Overview' ? 'Good morning, Rajan' : activeNav}</h1><p>Here’s what’s happening with your sales pipeline today.</p></div><div className="heading-actions"><button className="btn btn-outline" onClick={exportCsv}><Download size={16}/> Export</button><button className="btn btn-primary" onClick={() => setShowModal(true)}><Plus size={17}/> Add lead</button></div></section>

          {notice && <div className="toast-message"><CheckCircle2 size={17}/>{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}

          <section className="stats-grid">
            <StatCard title="Total leads" value={leads.length.toString()} change="+12.8%" trend="up" caption="vs. last month" icon={<ContactRound/>} tone="purple"/>
            <StatCard title="Pipeline value" value={money(totalPipeline)} change="+8.2%" trend="up" caption="vs. last month" icon={<CircleDollarSign/>} tone="blue"/>
            <StatCard title="Won deals" value={wonCount.toString()} change="+2.4%" trend="up" caption="vs. last month" icon={<Target/>} tone="green"/>
            <StatCard title="Conversion rate" value={`${conversion}%`} change="-1.1%" trend="down" caption="vs. last month" icon={<ChartNoAxesCombined/>} tone="orange"/>
          </section>

          <section className="content-grid">
            <div className="panel pipeline-panel"><div className="panel-heading"><div><h3>Sales performance</h3><p>Revenue generated over time</p></div><button className="select-button">Last 7 months <ChevronDown size={14}/></button></div><div className="chart-legend"><span><i className="legend-dot purple-dot"/> Revenue</span><span><i className="legend-dot pale-dot"/> Target</span></div><div className="chart-wrap"><div className="y-labels"><span>₹80k</span><span>₹60k</span><span>₹40k</span><span>₹20k</span><span>₹0</span></div><div className="chart-area"><div className="grid-lines"><i/><i/><i/><i/><i/></div><svg viewBox="0 0 700 210" preserveAspectRatio="none" className="chart-svg"><defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#8066e8" stopOpacity=".22"/><stop offset="100%" stopColor="#8066e8" stopOpacity="0"/></linearGradient></defs><path d="M0 165 C35 150 45 130 90 140 S145 105 185 120 S235 75 280 100 S330 80 370 95 S420 48 465 68 S515 38 555 65 S625 28 700 35 L700 210 L0 210Z" fill="url(#areaFill)"/><path d="M0 165 C35 150 45 130 90 140 S145 105 185 120 S235 75 280 100 S330 80 370 95 S420 48 465 68 S515 38 555 65 S625 28 700 35" fill="none" stroke="#8066e8" strokeWidth="3" vectorEffect="non-scaling-stroke" strokeLinecap="round"/></svg><div className="x-labels"><span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span><span>Nov</span></div></div></div></div>
            <div className="panel source-panel"><div className="panel-heading"><div><h3>Lead sources</h3><p>Where your leads come from</p></div><MoreHorizontal size={19}/></div><div className="donut-area"><div className="donut"><div className="donut-center"><strong>{leads.length}</strong><small>Total leads</small></div></div></div><div className="source-list"><Source label="Website" value="42%" width="42%" color="bar-purple"/><Source label="Referral" value="28%" width="28%" color="bar-blue"/><Source label="LinkedIn" value="18%" width="18%" color="bar-orange"/><Source label="Campaign" value="12%" width="12%" color="bar-green"/></div></div>
          </section>

          <section className="panel leads-panel"><div className="panel-heading leads-heading"><div><h3>Recent leads <span className="subtle-count">{filtered.length}</span></h3><p>Keep track of your latest opportunities</p></div><button className="btn btn-text" onClick={() => setActiveNav('Leads')}>View all <ArrowUpRight size={15}/></button></div><div className="table-toolbar"><div className="table-search"><Search size={15}/><input placeholder="Search leads..." value={query} onChange={e => setQuery(e.target.value)}/></div><div className="toolbar-right"><div className="filter-wrap"><Filter size={14}/><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option>All statuses</option>{['New','Qualified','Proposal','Won','Lost'].map(s => <option key={s}>{s}</option>)}</select></div><button className="btn btn-outline btn-small" onClick={exportCsv}><Download size={14}/> Export</button></div></div>
            <div className="table-scroll"><table><thead><tr><th><input type="checkbox" aria-label="Select all leads"/></th><th>LEAD NAME</th><th>COMPANY</th><th>STATUS</th><th>VALUE</th><th>OWNER</th><th>CREATED</th><th></th></tr></thead><tbody>
              {filtered.map(lead => <tr key={lead.id}><td><input type="checkbox" aria-label={`Select ${lead.name}`}/></td><td><div className="lead-person"><div className={`lead-avatar ${lead.color}`}>{lead.initials}</div><div><strong>{lead.name}</strong><small>{lead.email}</small></div></div></td><td className="company-cell">{lead.company}</td><td><select className={`status-select ${statusClass(lead.status)}`} value={lead.status} onChange={e => changeStatus(lead.id,e.target.value)} aria-label={`Status for ${lead.name}`}>{['New','Qualified','Proposal','Won','Lost'].map(s => <option key={s}>{s}</option>)}</select></td><td className="value-cell">{money(lead.value)}</td><td><div className="owner"><div className="owner-avatar">{lead.owner.split(' ').map(x=>x[0]).join('')}</div>{lead.owner}</div></td><td className="date-cell">{lead.date}</td><td><button className="row-more" onClick={() => setNotice(`${lead.name} · ${lead.phone}`)}><MoreHorizontal size={18}/></button></td></tr>)}
              {filtered.length === 0 && <tr><td colSpan="8" className="empty-state">No leads match your search.</td></tr>}
            </tbody></table></div><div className="table-footer"><span>Showing <b>{filtered.length}</b> of <b>{leads.length}</b> leads</span><div><button disabled>Previous</button><button className="current-page">1</button><button disabled>Next</button></div></div>
          </section>
          <footer className="page-footer"><span>© 2026 NovaCRM. All rights reserved.</span><span>Made for better relationships <span className="heart">♥</span></span></footer>
        </div>
      </main>

      {showModal && <div className="modal-backdrop" onMouseDown={e => {if(e.target===e.currentTarget)setShowModal(false);}}><div className="modal-card"><div className="modal-heading"><div><h2>Add new lead</h2><p>Enter the details of your new opportunity.</p></div><button className="icon-button" onClick={() => setShowModal(false)}><X size={19}/></button></div><form onSubmit={addLead}><div className="form-grid"><label>Full name *<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Neha Gupta"/></label><label>Company *<input required value={form.company} onChange={e=>setForm({...form,company:e.target.value})} placeholder="Company name"/></label><label>Email address *<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="name@company.com"/></label><label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="+91 98765 43210"/></label><label>Deal value (₹) *<input required min="1" type="number" value={form.value} onChange={e=>setForm({...form,value:e.target.value})} placeholder="25000"/></label><label>Lead source<select value={form.source} onChange={e=>setForm({...form,source:e.target.value})}><option>Website</option><option>Referral</option><option>LinkedIn</option><option>Campaign</option></select></label><label>Lead owner<select value={form.owner} onChange={e=>setForm({...form,owner:e.target.value})}><option>Priya S.</option><option>Rahul K.</option><option>Arjun M.</option></select></label></div><div className="modal-actions"><button type="button" className="btn btn-outline" onClick={()=>setShowModal(false)}>Cancel</button><button type="submit" className="btn btn-primary"><Plus size={16}/> Create lead</button></div></form></div></div>}
    </div>
  );
}

function StatCard({title,value,change,trend,caption,icon,tone}) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-title">{title}</div><div className="stat-value">{value}</div><div className="stat-foot"><span className={`trend ${trend}`}>{trend==='up'?<ArrowUpRight size={14}/>:<ArrowDownRight size={14}/>} {change}</span><span>{caption}</span></div></div>;
}
function Source({label,value,width,color}) { return <div className="source-row"><div className="source-meta"><span>{label}</span><strong>{value}</strong></div><div className="source-track"><i className={color} style={{width}}/></div></div>; }

export default App;
