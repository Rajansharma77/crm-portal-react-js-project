# NovaCRM — React CRM Dashboard

A responsive CRM sales dashboard built with React, Vite, Lucide icons, and custom CSS.

## Features
- Responsive desktop and mobile layout
- KPI cards for leads, pipeline value, won deals, and conversion
- Sales performance chart and lead-source visualization
- Leads table with search and status filtering
- Add lead modal with basic form validation
- Update lead status inline
- Export filtered leads to CSV
- Demo data included

## Requirements
- Node.js 18 or newer
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Production build
```bash
npm run build
npm run preview
```

## GitHub upload
Create a repository on GitHub, extract this ZIP, open a terminal in the project folder, and run:
```bash
git init
git add .
git commit -m "Build React CRM dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the remote URL with your own repository URL.

## Notes
This is a frontend portfolio/demo project. Leads are held in React state and reset when the page reloads. There is no backend, database, authentication, or real email/phone integration. Add an API and database for persistent multi-user use.
